import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Menu, Upload, Video } from "lucide-react";
import { motion } from "motion/react";
import BottomSheet from "../components/ds/BottomSheet";
import Button from "../components/ds/Button";
import HandTrace from "../components/ds/HandTrace";
import Logo from "../components/ds/Logo";
import StatusBadge from "../components/ds/StatusBadge";
import {
  ISHARA_EASE,
  StaggerContainer,
  StaggerItem,
  SurfaceCard,
  usePrefersReducedMotion,
} from "../components/ds/MotionPrimitives";

const WORKFLOW_STEPS = [
  {
    num: "01",
    title: "Choose camera or video",
    description:
      "Record a live signing clip directly in your browser or choose a previously recorded MP4, WebM, or AVI file from your device.",
    badge: null,
  },
  {
    num: "02",
    title: "Review before you submit",
    description:
      "Play back your recording in a clear, unobstructed preview so your hands, face, and natural expression stay clearly visible.",
    badge: null,
  },
  {
    num: "03",
    title: "Translation when ready",
    description:
      "Reviewed clips are prepared for Pakistan Sign Language translation once processing connects—no hidden steps or guesswork.",
    badge: "Coming soon",
  },
];

const QUALITIES = [
  {
    title: "Clear framing without distractions",
    description:
      "Camera previews keep your upper body and hand movement natural and unmirrored so every sign reads accurately.",
  },
  {
    title: "Honest status at every step",
    description:
      "Browser permissions, file format checks, and service availability are explained plainly—never hidden behind fake progress.",
  },
  {
    title: "Readable on every screen",
    description:
      "High-contrast editorial typography, 44px touch targets, and keyboard-first controls adapt across mobile, tablet, and desktop.",
  },
  {
    title: "Accessible by design",
    description:
      "Respects reduced-motion preferences, announces live status updates, and supports full keyboard navigation throughout.",
  },
];

export default function Landing() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    document.title = "ISHARA AI — Communication without barriers";
    function onScroll() {
      setScrolled(window.scrollY > 24);
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  function closeMobileMenu() {
    setMobileMenuOpen(false);
  }

  return (
    <div className="ds-landing">
      <a className="ds-skip-link" href="#landing-main">
        Skip to main content
      </a>

      <header
        className={`ds-landing-header ${scrolled ? "is-scrolled" : "ds-on-dark"}`.trim()}
      >
        <div className="ds-landing-header-inner">
          <Logo to="/" surface={scrolled ? "light" : "dark"} ariaLabel="ISHARA AI home" />

          <nav className="ds-landing-nav-desktop" aria-label="Landing navigation">
            <a href="#how-it-works">How it works</a>
            <a href="#two-ways-to-start">Two ways to start</a>
            <a href="#easy-to-use">Accessibility</a>
          </nav>

          <div className="ds-landing-header-actions">
            <Button variant={scrolled ? "tertiary" : "on-dark-tertiary"} size="sm" to="/login">
              Sign in
            </Button>
            <Button variant={scrolled ? "primary" : "on-dark-secondary"} size="sm" to="/signup">
              Create account
            </Button>
          </div>

          <button
            type="button"
            className={`ds-icon-btn ${scrolled ? "" : "ds-icon-btn--on-dark"} ds-landing-menu-btn`.trim()}
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open navigation menu"
            aria-expanded={mobileMenuOpen}
            aria-haspopup="dialog"
          >
            <Menu size={22} strokeWidth={2} aria-hidden="true" />
          </button>
        </div>
      </header>

      <main id="landing-main" tabIndex={-1}>
        <section className="ds-landing-hero ds-on-dark">
          <div className="ds-landing-hero-bg-trace" aria-hidden="true">
            <HandTrace variant="loop" />
          </div>

          <div className="ds-landing-hero-inner">
            <StaggerContainer className="ds-landing-hero-copy" stagger={0.075} delay={0.05}>
              <StaggerItem y={10}>
                <span className="ds-eyebrow ds-landing-hero-eyebrow">
                  Pakistan Sign Language
                </span>
              </StaggerItem>
              <StaggerItem y={16}>
                <h1 className="ds-display-xl ds-landing-hero-title" style={{ animation: "none" }}>
                  Communication{" "}
                  <span className="ds-serif-accent">without barriers.</span>
                </h1>
              </StaggerItem>
              <StaggerItem y={14}>
                <p className="ds-landing-hero-lead" style={{ animation: "none" }}>
                  A calm, accessible platform to record or upload Pakistan Sign
                  Language videos—designed for clear framing, honest feedback, and
                  everyday connection.
                </p>
              </StaggerItem>

              <StaggerItem y={12}>
                <div className="ds-landing-hero-ctas" style={{ animation: "none" }}>
                  <Button variant="yellow" size="hero" to="/signup">
                    <span>Create account</span>
                    <ArrowRight
                      size={18}
                      strokeWidth={2}
                      className="ds-rtl-flip"
                      aria-hidden="true"
                    />
                  </Button>
                  <Button variant="on-dark-secondary" size="hero" to="/login">
                    Sign in
                  </Button>
                </div>
              </StaggerItem>
            </StaggerContainer>

            <motion.div
              className="ds-landing-arch-frame"
              aria-hidden="true"
              initial={reduced ? false : { opacity: 0, scale: 0.96, y: 18 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: reduced ? 0.01 : 0.48, delay: 0.12, ease: ISHARA_EASE }}
              whileHover={reduced ? undefined : { y: -4 }}
            >
              <div className="ds-floating" style={{ inlineSize: "100%", color: "#c4f3e7" }}>
                <HandTrace variant="loop" animated />
              </div>
              <p className="ds-serif-accent ds-landing-arch-caption">
                Natural hand motion and clear visual space for every sign.
              </p>
            </motion.div>
          </div>

          <svg
            className="ds-landing-hero-curve"
            viewBox="0 0 1440 72"
            preserveAspectRatio="none"
            aria-hidden="true"
            focusable="false"
          >
            <path
              d="M0 36C240 72 480 4 720 34C960 64 1200 12 1440 42V72H0V36Z"
              fill="currentColor"
            />
          </svg>
        </section>

        <section
          id="how-it-works"
          className="ds-landing-section"
          aria-labelledby="how-it-works-title"
        >
          <div className="ds-landing-container">
            <motion.div
              className="ds-landing-section-head"
              initial={reduced ? false : { opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-48px" }}
              transition={{ duration: reduced ? 0.01 : 0.34, ease: ISHARA_EASE }}
            >
              <span className="ds-eyebrow">Workflow</span>
              <h2 id="how-it-works-title" className="ds-h1">
                How it works
              </h2>
            </motion.div>

            <StaggerContainer viewportOnce stagger={0.08}>
              <ol className="ds-timeline" style={{ listStyle: "none", margin: 0 }}>
                {WORKFLOW_STEPS.map((step) => (
                  <li key={step.num} className="ds-timeline-step">
                    <StaggerItem y={16}>
                      <span className="ds-timeline-num" aria-hidden="true">
                        {step.num}
                      </span>
                      <div style={{ display: "flex", alignItems: "center", gap: "var(--ds-space-3)", flexWrap: "wrap", marginBlock: "var(--ds-space-2)" }}>
                        <h3 className="ds-h3">{step.title}</h3>
                        {step.badge && (
                          <StatusBadge status={step.badge} tone="neutral" />
                        )}
                      </div>
                      <p className="ds-body" style={{ color: "var(--ds-text-secondary)" }}>
                        {step.description}
                      </p>
                    </StaggerItem>
                  </li>
                ))}
              </ol>
            </StaggerContainer>
          </div>
        </section>

        <section className="ds-landing-section ds-statement-band" aria-label="Platform principle">
          <motion.div
            className="ds-statement-inner"
            initial={reduced ? false : { opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-48px" }}
            transition={{ duration: reduced ? 0.01 : 0.38, ease: ISHARA_EASE }}
          >
            <div style={{ inlineSize: "min(100%, 16rem)", color: "var(--ds-text-accent)" }}>
              <HandTrace variant="arc" />
            </div>
            <blockquote
              className="ds-serif-accent ds-statement-quote"
              style={{ margin: 0 }}
            >
              “Every gesture carries meaning. Every conversation deserves clear
              space.”
            </blockquote>
            <p className="ds-body" style={{ color: "var(--ds-text-secondary)", maxWidth: "48ch" }}>
              Built in collaboration with accessibility principles so signers can
              focus on expression rather than cluttered interfaces.
            </p>
          </motion.div>
        </section>

        <section
          id="two-ways-to-start"
          className="ds-landing-section"
          aria-labelledby="two-ways-title"
        >
          <div className="ds-landing-container">
            <motion.div
              className="ds-landing-section-head"
              initial={reduced ? false : { opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-48px" }}
              transition={{ duration: reduced ? 0.01 : 0.34, ease: ISHARA_EASE }}
            >
              <span className="ds-eyebrow">Recording &amp; Upload</span>
              <h2 id="two-ways-title" className="ds-h1">
                Two ways to start
              </h2>
            </motion.div>

            <StaggerContainer viewportOnce className="ds-ways-grid" stagger={0.08}>
              <StaggerItem>
                <SurfaceCard as="article" interactive className="ds-way-primary ds-on-dark">
                  <div style={{ display: "flex", flexDirection: "column", gap: "var(--ds-space-4)" }}>
                    <span
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        inlineSize: "3rem",
                        blockSize: "3rem",
                        borderRadius: "var(--ds-radius-md)",
                        background: "var(--ish-yellow)",
                        border: "1px solid rgba(255, 255, 255, 0.4)",
                        color: "var(--ish-ink)",
                        boxShadow: "0 8px 20px -4px rgba(5, 85, 118, 0.34)",
                      }}
                      aria-hidden="true"
                    >
                      <Video size={24} strokeWidth={1.75} />
                    </span>
                    <h3 className="ds-h2">Use Live Camera</h3>
                    <p className="ds-body">
                      Preview your framing in real time, capture one complete
                      thought with your webcam, and review your recording before
                      submitting.
                    </p>
                  </div>
                  <div>
                    <Button variant="yellow" to="/signup">
                      <span>Start with Live Camera</span>
                      <ArrowRight
                        size={16}
                        strokeWidth={2}
                        className="ds-rtl-flip"
                        aria-hidden="true"
                      />
                    </Button>
                  </div>
                </SurfaceCard>
              </StaggerItem>

              <StaggerItem>
                <SurfaceCard as="article" interactive className="ds-way-secondary">
                  <div style={{ display: "flex", flexDirection: "column", gap: "var(--ds-space-4)" }}>
                    <span
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        inlineSize: "3rem",
                        blockSize: "3rem",
                        borderRadius: "var(--ds-radius-md)",
                        backgroundColor: "var(--ds-bg-surface)",
                        border: "1px solid var(--ds-border-divider)",
                        boxShadow: "var(--ds-shadow-1)",
                        color: "var(--ds-text-link)",
                      }}
                      aria-hidden="true"
                    >
                      <Upload size={24} strokeWidth={1.75} />
                    </span>
                    <h3 className="ds-h2">Upload a Video</h3>
                    <p className="ds-body">
                      Select a previously recorded MP4, WebM, or browser-playable
                      AVI file up to 250 MB and verify playback first.
                    </p>
                  </div>
                  <div>
                    <Button variant="secondary" to="/login">
                      <span>Sign in to upload</span>
                      <ArrowRight
                        size={16}
                        strokeWidth={2}
                        className="ds-rtl-flip"
                        aria-hidden="true"
                      />
                    </Button>
                  </div>
                </SurfaceCard>
              </StaggerItem>
            </StaggerContainer>
          </div>
        </section>

        <section
          id="easy-to-use"
          className="ds-landing-section"
          style={{ paddingBlockStart: 0 }}
          aria-labelledby="qualities-title"
        >
          <div className="ds-landing-container">
            <motion.div
              className="ds-landing-section-head"
              initial={reduced ? false : { opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-48px" }}
              transition={{ duration: reduced ? 0.01 : 0.34, ease: ISHARA_EASE }}
            >
              <span className="ds-eyebrow">Standards</span>
              <h2 id="qualities-title" className="ds-h1">
                Designed to be easy to use
              </h2>
            </motion.div>

            <StaggerContainer viewportOnce className="ds-qualities-list" stagger={0.055}>
              {QUALITIES.map((item) => (
                <StaggerItem key={item.title} y={10}>
                  <article className="ds-quality-row">
                    <h3 className="ds-h4">{item.title}</h3>
                    <p className="ds-body" style={{ color: "var(--ds-text-secondary)" }}>
                      {item.description}
                    </p>
                  </article>
                </StaggerItem>
              ))}
            </StaggerContainer>
          </div>
        </section>

        <section className="ds-closing-band ds-on-dark" aria-labelledby="closing-cta-title">
          <motion.div
            className="ds-closing-inner"
            initial={reduced ? false : { opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-48px" }}
            transition={{ duration: reduced ? 0.01 : 0.38, ease: ISHARA_EASE }}
          >
            <span className="ds-eyebrow" style={{ color: "var(--ds-text-on-brand-accent)" }}>
              Get Started
            </span>
            <h2 id="closing-cta-title" className="ds-display-l">
              Ready to connect through{" "}
              <span className="ds-serif-accent">
                Ishara AI?
              </span>
            </h2>
            <p className="ds-body-lg">
              Create your account or sign in to access your recording workspace
              and translation history.
            </p>
            <div className="ds-landing-hero-ctas" style={{ justifyContent: "center" }}>
              <Button variant="yellow" size="lg" to="/signup">
                Create account
              </Button>
              <Button variant="on-dark-secondary" size="lg" to="/login">
                Sign in
              </Button>
            </div>
          </motion.div>
        </section>
      </main>

      <footer className="ds-landing-footer ds-on-dark">
        <div className="ds-landing-footer-inner">
          <div style={{ display: "flex", alignItems: "center", gap: "var(--ds-space-4)", flexWrap: "wrap" }}>
            <Logo to="/" surface="dark" />
            <span style={{ fontSize: "0.875rem" }}>
              © 2026 ISHARA AI — Pakistani Sign Language Communication Platform
            </span>
          </div>

          <nav className="ds-landing-footer-links" aria-label="Footer navigation">
            <Link to="/login">Sign in</Link>
            <Link to="/signup">Create account</Link>
            <Link to="/forgot-password">Forgot password</Link>
          </nav>
        </div>
      </footer>

      <BottomSheet
        open={mobileMenuOpen}
        onClose={closeMobileMenu}
        title="ISHARA AI"
        ariaLabel="Landing navigation menu"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--ds-space-2)" }}>
          <a href="#how-it-works" className="ds-menu-item" onClick={closeMobileMenu}>
            How it works
          </a>
          <a href="#two-ways-to-start" className="ds-menu-item" onClick={closeMobileMenu}>
            Two ways to start
          </a>
          <a href="#easy-to-use" className="ds-menu-item" onClick={closeMobileMenu}>
            Accessibility
          </a>
          <hr
            style={{
              border: 0,
              borderBlockStart: "1px solid var(--ds-border-divider)",
              marginBlock: "var(--ds-space-2)",
            }}
          />
          <Button variant="primary" fullWidth to="/signup" onClick={closeMobileMenu}>
            Create account
          </Button>
          <Button variant="secondary" fullWidth to="/login" onClick={closeMobileMenu}>
            Sign in
          </Button>
        </div>
      </BottomSheet>
    </div>
  );
}
