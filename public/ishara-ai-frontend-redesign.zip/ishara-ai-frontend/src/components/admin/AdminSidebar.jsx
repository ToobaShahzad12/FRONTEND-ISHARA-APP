import { NavLink } from "react-router-dom";
import {
  Activity,
  BookOpenText,
  Hand,
  LayoutDashboard,
  ScrollText,
  Settings,
  Users,
  X,
} from "lucide-react";
import Drawer from "../ds/Drawer";
import HandTrace from "../ds/HandTrace";

const NAV_GROUPS = [
  {
    group: "Overview",
    items: [
      { label: "Overview", path: "/admin", Icon: LayoutDashboard, end: true },
    ],
  },
  {
    group: "People",
    items: [
      { label: "Users", path: "/admin/users", Icon: Users },
    ],
  },
  {
    group: "Content",
    items: [
      { label: "PSL dictionary", path: "/admin/psl-dictionary", Icon: Hand },
      { label: "Knowledge base", path: "/admin/knowledge-base", Icon: BookOpenText },
    ],
  },
  {
    group: "Operations",
    items: [
      { label: "System logs", path: "/admin/system-logs", Icon: ScrollText },
      { label: "Processing activity", path: "/admin/processing-activity", Icon: Activity },
    ],
  },
  {
    group: "Account",
    items: [
      { label: "Profile & settings", path: "/admin/profile-settings", Icon: Settings },
    ],
  },
];

function SidebarContent({ onNavigate, onCloseMobile, isDrawer = false }) {
  return (
    <div className="ds-admin-sidebar-inner ds-on-dark">
      <div
        className="ds-admin-brand"
        style={{ justifyContent: isDrawer ? "space-between" : "flex-start" }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", minInlineSize: 0 }}>
          <span style={{ color: "var(--ds-text-on-brand-accent)", flexShrink: 0 }}>
            <HandTrace variant="mark" />
          </span>
          <div className="ds-admin-brand-text">
            <h2
              style={{
                fontFamily: "var(--ds-font-display)",
                fontWeight: 600,
                fontSize: "1.375rem",
                letterSpacing: "0.02em",
                textTransform: "lowercase",
                color: "var(--ds-text-on-brand)",
                lineHeight: 1.05,
              }}
            >
              ishara<span style={{ color: "var(--ds-text-on-brand-accent)" }}>.ai</span>
            </h2>
            <span className="ds-admin-brand-eyebrow">ADMIN</span>
          </div>
        </div>

        {isDrawer && (
          <button
            type="button"
            className="ds-icon-btn ds-icon-btn--on-dark"
            onClick={onCloseMobile}
            aria-label="Close navigation menu"
          >
            <X size={20} strokeWidth={2} aria-hidden="true" />
          </button>
        )}
      </div>

      <nav className="ds-admin-nav" aria-label="Administration navigation">
        {NAV_GROUPS.map(({ group, items }) => (
          <div className="ds-admin-group" key={group}>
            <span className="ds-admin-group-label">{group}</span>
            {items.map(({ label, path, Icon, end }) => (
              <NavLink
                key={path}
                to={path}
                end={Boolean(end)}
                onClick={onNavigate}
                aria-label={label}
                title={label}
                className={({ isActive }) =>
                  `ds-admin-nav-link ${isActive ? "active" : ""}`.trim()
                }
              >
                <Icon size={20} strokeWidth={1.75} aria-hidden="true" />
                <span className="ds-admin-nav-text">{label}</span>
              </NavLink>
            ))}
          </div>
        ))}
      </nav>
    </div>
  );
}

function AdminSidebar({ mobileOpen = false, onCloseMobile }) {
  return (
    <>
      <aside className="ds-admin-sidebar-desktop" aria-label="Admin sidebar">
        <SidebarContent />
      </aside>

      <Drawer
        open={mobileOpen}
        onClose={onCloseMobile}
        ariaLabel="Administration navigation menu"
      >
        <SidebarContent
          isDrawer
          onCloseMobile={onCloseMobile}
          onNavigate={onCloseMobile}
        />
      </Drawer>
    </>
  );
}

export default AdminSidebar;
