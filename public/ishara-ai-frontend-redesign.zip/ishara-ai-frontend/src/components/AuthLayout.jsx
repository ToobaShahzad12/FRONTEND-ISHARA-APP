import HandTrace from "./ds/HandTrace";
import Logo from "./ds/Logo";

export default function AuthLayout({
  children,
  pageClassName = "",
  layoutClassName = "",
  mainClassName = "",
}) {
  return (
    <main className={`ds-auth-page ${pageClassName} ${layoutClassName}`.trim()}>
      <aside className="ds-auth-brand ds-on-dark">
        <Logo to="/" surface="dark" ariaLabel="ISHARA AI home" />

        <div className="ds-auth-brand-body">
          <h1 className="ds-display-l ds-auth-brand-title">
            COMMUNICATION <span className="ds-serif-accent">without barriers.</span>
          </h1>
          <p className="ds-auth-brand-copy">
            A more accessible way to connect through Pakistan Sign Language.
          </p>
        </div>

        <p className="ds-auth-brand-footer">
          Pakistani Sign Language communication platform
        </p>

        <div className="ds-auth-brand-trace" aria-hidden="true">
          <HandTrace variant="loop" animated />
        </div>
      </aside>

      <section className={`ds-auth-main ${mainClassName}`.trim()}>
        {children}
      </section>
    </main>
  );
}
