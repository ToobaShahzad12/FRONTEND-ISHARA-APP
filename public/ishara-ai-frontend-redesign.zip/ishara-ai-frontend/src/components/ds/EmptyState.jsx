import HandTrace from "./HandTrace";

export default function EmptyState({
  icon: Icon,
  useHandTrace = false,
  title,
  description,
  actions,
  footnote,
  titleId,
  className = "",
}) {
  return (
    <div className={`ds-empty-state ${className}`.trim()}>
      {useHandTrace ? (
        <span style={{ color: "var(--ds-text-link)" }} aria-hidden="true">
          <HandTrace variant="trail" />
        </span>
      ) : Icon ? (
        <span className="ds-empty-icon" aria-hidden="true">
          <Icon size={28} strokeWidth={1.75} focusable="false" />
        </span>
      ) : null}

      {title && (
        <h2 id={titleId} className="ds-h3 ds-empty-title">
          {title}
        </h2>
      )}

      {description && <p className="ds-empty-desc">{description}</p>}

      {actions && <div className="ds-empty-actions">{actions}</div>}

      {footnote && (
        <p className="ds-serif-accent ds-body" style={{ color: "var(--ds-text-muted)" }}>
          {footnote}
        </p>
      )}
    </div>
  );
}
