import HandTrace from "./HandTrace";

export default function PageHeader({
  eyebrow,
  title,
  description,
  actions,
  showRule = false,
  titleId,
  uppercaseTitle = false,
  className = "",
}) {
  return (
    <header className={`ds-page-header ${className}`.trim()}>
      <div className="ds-page-header-row">
        <div className="ds-page-header-copy">
          {eyebrow && <span className="ds-eyebrow ds-page-header-eyebrow">{eyebrow}</span>}
          <h1
            id={titleId}
            className={`ds-h1 ${uppercaseTitle ? "ds-h1--upper" : ""} ds-page-header-title`.trim()}
          >
            {title}
          </h1>
          {description && (
            <p className="ds-body ds-page-header-desc">{description}</p>
          )}
        </div>
        {actions && <div className="ds-page-header-actions">{actions}</div>}
      </div>

      {showRule && (
        <div style={{ color: "var(--ds-text-link)", opacity: 0.35, maxInlineSize: "24rem" }}>
          <HandTrace variant="arc" />
        </div>
      )}
    </header>
  );
}
