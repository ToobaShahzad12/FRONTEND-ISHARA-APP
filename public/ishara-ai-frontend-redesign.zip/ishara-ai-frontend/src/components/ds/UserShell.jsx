import { useEffect, useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  History,
  LayoutDashboard,
  LogOut,
  Upload,
  UserRound,
  Video,
} from "lucide-react";
import { logoutUser } from "../../api/auth";
import Avatar from "./Avatar";
import BottomSheet from "./BottomSheet";
import Button from "./Button";
import Logo from "./Logo";

const NAV_ITEMS = [
  {
    path: "/dashboard",
    label: "Dashboard",
    mobileLabel: "Home",
    ariaLabel: "Dashboard",
    Icon: LayoutDashboard,
  },
  {
    path: "/dashboard/live-camera",
    label: "Live Camera",
    mobileLabel: "Camera",
    ariaLabel: "Live Camera",
    Icon: Video,
  },
  {
    path: "/dashboard/upload-video",
    label: "Upload Video",
    mobileLabel: "Upload",
    ariaLabel: "Upload Video",
    Icon: Upload,
  },
  {
    path: "/dashboard/translation-history",
    label: "History",
    mobileLabel: "History",
    ariaLabel: "Translation History",
    Icon: History,
  },
  {
    path: "/dashboard/profile-settings",
    label: "Profile",
    mobileLabel: "Profile",
    ariaLabel: "Profile and Settings",
    Icon: UserRound,
  },
];

export default function UserShell({
  user,
  onLogout,
  pageTitle = "Dashboard",
  children,
}) {
  const location = useLocation();
  const navigate = useNavigate();
  const mainRef = useRef(null);
  const [accountSheetOpen, setAccountSheetOpen] = useState(false);

  const name = user?.full_name?.trim() || "there";
  const email = user?.email || "";

  useEffect(() => {
    document.title = `${pageTitle} — ISHARA AI`;
  }, [pageTitle]);

  useEffect(() => {
    setAccountSheetOpen(false);
  }, [location.pathname]);

  function handleSignOut() {
    if (typeof onLogout === "function") {
      onLogout();
      return;
    }
    logoutUser();
    navigate("/login", { replace: true });
  }

  return (
    <div className="ds-user-shell">
      <a className="ds-skip-link" href="#user-main-content">
        Skip to main content
      </a>

      <header className="ds-user-topbar ds-on-dark">
        <div className="ds-user-topbar-inner">
          <Logo to="/dashboard" surface="dark" ariaLabel="Ishara.ai dashboard" />

          <nav className="ds-user-nav" aria-label="User dashboard navigation">
            {NAV_ITEMS.map(({ path, label, ariaLabel }) => {
              const isCurrent = location.pathname === path;
              return (
                <Link
                  key={path}
                  to={path}
                  className="ds-user-nav-link"
                  aria-label={ariaLabel}
                  aria-current={isCurrent ? "page" : undefined}
                >
                  {label}
                </Link>
              );
            })}
          </nav>

          <div className="ds-user-account-desktop">
            <Avatar name={name} size="sm" />
            <span className="ds-user-account-name" title={name}>
              {name}
            </span>
            <Button
              variant="on-dark-tertiary"
              size="sm"
              onClick={handleSignOut}
            >
              <LogOut size={16} strokeWidth={2} aria-hidden="true" />
              <span>Sign out</span>
            </Button>
          </div>

          <button
            type="button"
            className="ds-user-mobile-account-btn"
            onClick={() => setAccountSheetOpen(true)}
            aria-label={`Open account menu for ${name}`}
            aria-haspopup="dialog"
            aria-expanded={accountSheetOpen}
          >
            <Avatar name={name} size="sm" />
          </button>
        </div>
      </header>

      <main
        id="user-main-content"
        ref={mainRef}
        tabIndex={-1}
        className="ds-user-main ds-page-enter"
      >
        {children}
      </main>

      <nav className="ds-user-bottom-nav ds-on-dark" aria-label="Mobile dashboard navigation">
        {NAV_ITEMS.map(({ path, mobileLabel, ariaLabel, Icon }) => {
          const isCurrent = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className="ds-bottom-tab"
              aria-label={ariaLabel}
              aria-current={isCurrent ? "page" : undefined}
            >
              <Icon size={22} strokeWidth={1.75} aria-hidden="true" />
              <span>{mobileLabel}</span>
            </Link>
          );
        })}
      </nav>

      <BottomSheet
        open={accountSheetOpen}
        onClose={() => setAccountSheetOpen(false)}
        title="Account"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--ds-space-4)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "var(--ds-space-3)" }}>
            <Avatar name={name} size="md" />
            <div style={{ minInlineSize: 0 }}>
              <strong style={{ display: "block", fontSize: "1rem" }}>{name}</strong>
              {email && (
                <span style={{ display: "block", fontSize: "0.875rem", color: "var(--ds-text-muted)", wordBreak: "break-word" }}>
                  {email}
                </span>
              )}
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "var(--ds-space-2)" }}>
            <Link
              to="/dashboard/profile-settings"
              className="ds-menu-item"
              onClick={() => setAccountSheetOpen(false)}
            >
              <UserRound size={18} strokeWidth={1.75} aria-hidden="true" />
              <span>Profile / Settings</span>
            </Link>
            <button
              type="button"
              className="ds-menu-item ds-menu-item--danger"
              onClick={handleSignOut}
            >
              <LogOut size={18} strokeWidth={1.75} aria-hidden="true" />
              <span>Sign out</span>
            </button>
          </div>
        </div>
      </BottomSheet>
    </div>
  );
}
