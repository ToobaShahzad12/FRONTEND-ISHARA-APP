import { useEffect, useRef } from "react";
import { X } from "lucide-react";

function getFocusableElements(container) {
  if (!container) return [];
  return Array.from(
    container.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )
  ).filter((el) => !el.hasAttribute("hidden") && el.offsetParent !== null);
}

export default function BottomSheet({
  open,
  onClose,
  title,
  ariaLabel,
  children,
}) {
  const panelRef = useRef(null);
  const previousFocusRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    previousFocusRef.current = document.activeElement;

    const panel = panelRef.current;
    const focusables = getFocusableElements(panel);
    if (focusables.length) {
      focusables[0].focus();
    } else {
      panel?.focus();
    }

    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    function handleKeyDown(event) {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose?.();
        return;
      }

      if (event.key === "Tab" && panel) {
        const items = getFocusableElements(panel);
        if (!items.length) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = prevOverflow;
      if (previousFocusRef.current && typeof previousFocusRef.current.focus === "function") {
        previousFocusRef.current.focus();
      }
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <>
      <div className="ds-scrim" onClick={onClose} aria-hidden="true" />
      <div
        ref={panelRef}
        className="ds-sheet-panel"
        role="dialog"
        aria-modal="true"
        aria-label={ariaLabel || title || "Options"}
        tabIndex={-1}
      >
        <div className="ds-sheet-header">
          {title ? <h2 className="ds-h4">{title}</h2> : <span />}
          <button
            type="button"
            className="ds-icon-btn"
            onClick={onClose}
            aria-label="Close panel"
          >
            <X size={20} strokeWidth={2} aria-hidden="true" />
          </button>
        </div>
        {children}
      </div>
    </>
  );
}
