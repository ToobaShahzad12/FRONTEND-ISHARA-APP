import { useEffect } from "react";
import Button from "../components/ds/Button";
import HandTrace from "../components/ds/HandTrace";
import Logo from "../components/ds/Logo";

export default function NotFound() {
  useEffect(() => {
    document.title = "Page not found — ISHARA AI";
  }, []);

  return (
    <div className="ds-notfound-page ds-on-dark">
      <header>
        <Logo to="/" surface="dark" ariaLabel="ISHARA AI home" />
      </header>

      <main className="ds-notfound-main">
        <div className="ds-notfound-code">
          <span className="ds-notfound-code-text" aria-hidden="true">
            404
          </span>
          <div style={{ inlineSize: "min(45vw, 15rem)", color: "var(--ds-accent-gold)" }}>
            <HandTrace variant="notfound" animated />
          </div>
        </div>

        <h1 className="ds-h1">We can’t find that page.</h1>
        <p className="ds-body-lg ds-notfound-lead">
          The link you opened may have moved, or the address might be typed
          incorrectly.
        </p>

        <div className="ds-notfound-actions">
          <Button variant="gold" size="lg" to="/">
            Back to home
          </Button>
          <Button variant="on-dark-secondary" size="lg" to="/login">
            Sign in
          </Button>
        </div>
      </main>

      <footer style={{ fontSize: "0.875rem", color: "var(--ds-text-on-brand-secondary)" }}>
        ISHARA AI — Communication without barriers
      </footer>
    </div>
  );
}
