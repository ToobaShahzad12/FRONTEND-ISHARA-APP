import { useNavigate } from "react-router-dom";
import { ArrowRight, Upload, Video } from "lucide-react";
import Button from "../components/ds/Button";
import EmptyState from "../components/ds/EmptyState";
import StatusBadge from "../components/ds/StatusBadge";
import UserShell from "../components/ds/UserShell";

export default function Dashboard({ user }) {
  const navigate = useNavigate();
  const name = user?.full_name?.trim() || "there";

  return (
    <UserShell user={user} pageTitle="Dashboard">
      <section className="ds-dash-welcome" aria-labelledby="ds-user-welcome-title">
        <span className="ds-eyebrow" style={{ color: "var(--ds-text-accent)" }}>
          Your workspace
        </span>
        <h1 id="ds-user-welcome-title" className="ds-h1">
          Hello, {name}
        </h1>
        <p className="ds-body-lg" style={{ color: "var(--ds-text-secondary)", maxWidth: "52ch" }}>
          Welcome back to Ishara AI. Ready to communicate?
        </p>
      </section>

      <section className="ds-dash-start-grid" aria-label="Translation options">
        <article className="ds-dash-hero-panel ds-on-dark">
          <div style={{ display: "flex", flexDirection: "column", gap: "var(--ds-space-4)" }}>
            <div className="ds-dash-panel-top">
              <span className="ds-dash-panel-icon" aria-hidden="true">
                <Video size={24} strokeWidth={1.75} />
              </span>
              <StatusBadge status="Live" tone="gold" />
            </div>
            <h2 className="ds-h2">Use Live Camera</h2>
            <p className="ds-body">Record your PSL signing using your camera.</p>
          </div>

          <div>
            <Button
              variant="gold"
              size="lg"
              onClick={() => navigate("/dashboard/live-camera")}
            >
              <span>Open Camera</span>
              <ArrowRight
                size={18}
                strokeWidth={2}
                className="ds-rtl-flip"
                aria-hidden="true"
              />
            </Button>
          </div>
        </article>

        <article className="ds-dash-secondary-panel">
          <div style={{ display: "flex", flexDirection: "column", gap: "var(--ds-space-4)" }}>
            <div className="ds-dash-panel-top">
              <span className="ds-dash-panel-icon" aria-hidden="true">
                <Upload size={24} strokeWidth={1.75} />
              </span>
              <StatusBadge status="Recorded" tone="neutral" />
            </div>
            <h2 className="ds-h2">Upload a Video</h2>
            <p className="ds-body">Choose a previously recorded PSL video.</p>
          </div>

          <div>
            <Button
              variant="secondary"
              size="lg"
              onClick={() => navigate("/dashboard/upload-video")}
            >
              <span>Choose Video</span>
              <ArrowRight
                size={18}
                strokeWidth={2}
                className="ds-rtl-flip"
                aria-hidden="true"
              />
            </Button>
          </div>
        </article>
      </section>

      <section
        className="ds-dash-recent-section"
        aria-labelledby="ds-user-history-title"
      >
        <div className="ds-dash-section-head">
          <div>
            <h2 id="ds-user-history-title" className="ds-h3">
              Recent Translations
            </h2>
            <p className="ds-body-sm" style={{ color: "var(--ds-text-secondary)" }}>
              Your completed and in-progress translations will appear here.
            </p>
          </div>

          <Button
            variant="tertiary"
            size="sm"
            to="/dashboard/translation-history"
          >
            View All
          </Button>
        </div>

        <EmptyState
          useHandTrace
          title="No translations yet"
          description="Your recent translations will show up here once you get started."
        />
      </section>

      <footer className="ds-dash-footer">
        <p className="ds-serif-accent ds-body-lg">
          Communication without barriers.
        </p>
      </footer>
    </UserShell>
  );
}
